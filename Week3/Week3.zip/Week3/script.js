const filterButtons = document.querySelectorAll(".filter-button");
const songCards = document.querySelectorAll(".song-card");
const filterCount = document.querySelector(".filter-count");

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const filter = button.dataset.filter;
    let visibleCount = 0;

    filterButtons.forEach((item) => {
      const isActive = item === button;
      item.classList.toggle("is-active", isActive);
      item.setAttribute("aria-pressed", String(isActive));
    });

    songCards.forEach((card) => {
      const moods = card.dataset.mood.split(" ");
      const isVisible = filter === "all" || moods.includes(filter);
      card.hidden = !isVisible;
      if (isVisible) visibleCount += 1;
    });

    filterCount.textContent = `SHOWING ${String(visibleCount).padStart(2, "0")} TRACKS`;
  });
});

document.querySelector("#current-year").textContent = new Date().getFullYear();
